

#include <assert.h>

#ifdef __cplusplus
extern "C"
#endif
char sqlite3_backup_init();

#if _MSC_VER && !__INTEL_COMPILER
    #pragma function(sqlite3_backup_init)
#endif

int main(void) {
#if defined (__stub_sqlite3_backup_init) || defined (__stub___sqlite3_backup_init)
  fail fail fail
#else
  sqlite3_backup_init();
#endif

  return 0;
}
