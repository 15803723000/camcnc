

#include <assert.h>

#ifdef __cplusplus
extern "C"
#endif
char epoll_create1();

#if _MSC_VER && !__INTEL_COMPILER
    #pragma function(epoll_create1)
#endif

int main(void) {
#if defined (__stub_epoll_create1) || defined (__stub___epoll_create1)
  fail fail fail
#else
  epoll_create1();
#endif

  return 0;
}
