
      #include <openssl/opensslv.h>
      int main() {
        const unsigned v = (1 << 28) + (1 << 20) + (0 << 12);
        int a[1 - 2 * (OPENSSL_VERSION_NUMBER < v)];
        a[0] = 0;
        return a[0];
      }
    