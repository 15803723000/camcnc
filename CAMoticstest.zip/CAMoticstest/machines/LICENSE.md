Some of the data files in this directory are part of the GrblGru project and are
provided by the author with the terms below.  These terms apply only to files
in this directory.

********************************************************************************
COPYRIGHT and DISCLAIMER NOTICE

Copyright �2014 - 2017. 'toe'. All Rights Reserved. Permission to use, copy and
distribute this software and its documentation for educational, research, and
non-profit purposes, without fee and without a signed licensing agreement, is
hereby granted, provided that the above copyright notice, this paragraph and the
following two paragraphs appear in all copies and distributions.

IN NO EVENT SHALL 'toe' BE LIABLE TO ANY PARTY FOR DIRECT, INDIRECT, SPECIAL,
INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING LOST PROFITS, ARISING OUT OF THE
USE OF THIS SOFTWARE AND ITS DOCUMENTATION, EVEN IF 'toe' HAS BEEN ADVISED OF
THE POSSIBILITY OF SUCH DAMAGE.

'toe' SPECIFICALLY DISCLAIMS ANY WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE
SOFTWARE AND ACCOMPANYING DOCUMENTATION, IF ANY, PROVIDED HEREUNDER IS PROVIDED
"AS IS". 'toe' HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
ENHANCEMENTS, OR MODIFICATIONS.
********************************************************************************
