This is a stripped down version of cairo and pixman.
