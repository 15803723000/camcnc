/******************************************************************************\

  CAMotics is an Open-Source simulation and CAM software.
  Copyright (C) 2011-2019 Joseph Coffland <joseph@cauldrondevelopment.com>

  This program is free software: you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation, either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program.  If not, see <http://www.gnu.org/licenses/>.

\******************************************************************************/

#include "coordtabmanager.h"

#include "QtWin.h"
#include "NCEdit.h"
#include "GCodeHighlighter.h"
#include "TPLHighlighter.h"

#include <camotics/project/File.h>

#include <cbang/Exception.h>
#include <cbang/os/SystemUtilities.h>

#include <QFile>
#include <QString>
#include <QMessageBox>
#include <QSplitter>

using namespace CAMotics;
using namespace cb;
using namespace std;


coordtabmanager::coordtabmanager(QWidget *parent) :
  QTabWidget(parent), win(0), offset(1) {

  while (parent && !win) {
    win = dynamic_cast<QtWin *>(parent);
    parent = parent->parentWidget();
  }

  if (!win) THROW("QtWin not found");

  connect(this, SIGNAL(tabCloseRequested(int)),
          SLOT(on_tabCloseRequested(int)));
}


void coordtabmanager::open(const SmartPointer<Project::File> &file,
                          int line, int col) {
  // Check if we already have this file open in a tab检查是否已在选项卡中打开此文件


  unsigned tab;
  for (tab = offset; tab < (unsigned)QTabWidget::count(); tab++)
    if (getFile(tab) == file) break;

  // Create new tab创建新选项卡
  if ((unsigned)QTabWidget::count() <= tab) {
    SmartPointer<Highlighter> highlighter;
    if (file->isTPL()) highlighter = new TPLHighlighter;
    else highlighter = new GCodeHighlighter;

    QApplication::setOverrideCursor(Qt::WaitCursor);
    NCEdit *editor = new NCEdit(file, highlighter,this);

    QFile qFile(QString::fromUtf8(file->getPath().c_str()));
    qFile.open(QFile::ReadOnly);
    QString contents = qFile.readAll();
    qFile.close();
    contents.replace('\t', "  ");

    editor->loadDarkScheme();
    editor->setWordWrapMode(QTextOption::NoWrap);
    editor->setPlainText(contents);

    connect(editor, SIGNAL(find()), SIGNAL(find()));
    connect(editor, SIGNAL(findNext()), SIGNAL(findNext()));
    connect(editor, SIGNAL(findResult(bool)), SIGNAL(findResult(bool)));

    QString title = QString::fromUtf8(file->getBasename().c_str());
    tab = (unsigned)QTabWidget::addTab(editor, title);
    QApplication::restoreOverrideCursor();
  }
                          }
void coordtabmanager::validateTabIndex(unsigned tab) const {
  if (tab < offset || (unsigned)QTabWidget::count() <= tab)
    THROW("Invalid file tab index " << tab);
}

const SmartPointer<Project::File> &coordtabmanager::getFile(unsigned tab) const {
  validateTabIndex(tab);
  return ((NCEdit *)QTabWidget::widget(tab))->getFile();
}

